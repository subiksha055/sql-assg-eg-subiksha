package com.ordermanage.util;

import java.io.FileInputStream;
import java.io.IOException;
import java.util.Properties;

public class DBPropertyUtil {

	public static String getConnectionString(String propertyName) {
		Properties properties = loadProperties();
		return properties.getProperty(propertyName);
	}

	private static Properties loadProperties() {
		Properties properties = new Properties();
		try (FileInputStream input = new FileInputStream("db.properties")) {
			properties.load(input);
		} catch (IOException ex) {
			ex.printStackTrace();
		}
		return properties;
	}
}
