package com.ordermanage.main;

import java.sql.SQLException;
import java.time.LocalDate;
import java.util.List;
import java.util.Scanner;

import com.ordermanage.entity.Order;
import com.ordermanage.entity.Product;
import com.ordermanage.service.IOrderService;
import com.ordermanage.service.IProductService;
import com.ordermanage.service.OrderServiceImpl;
import com.ordermanage.service.ProductServiceImpl;
import com.ordermanage.util.DBUtil;

public class MainModule {

	public static void main(String[] args) {
		
		try {
			DBUtil.createConnection();
		} catch (ClassNotFoundException e) {
			e.printStackTrace();
		} catch (SQLException e) {
			e.printStackTrace();
		}

		IProductService productService = new ProductServiceImpl();
		IOrderService orderService = new OrderServiceImpl();

		Scanner scInput = new Scanner(System.in);

		int choice = -1;

		while (choice != 0) {
			System.out.println("Following are the options:");
			System.out.println("1. Product Management");
			System.out.println("2. Order Management");
			System.out.println("0. Exit");
			System.out.print("Please enter your choice: ");

			choice = scInput.nextInt();
			scInput.nextLine(); 

			switch (choice) {
			case 1:
				productManagement(scInput, productService);
				break;
			case 2:
				orderManagement(scInput, orderService, productService);
				break;
			case 0:
				System.out.println("Exiting the application. Goodbye!");
				break;
			default:
				System.out.println("Incorrect option. Please try again.");
				break;
			}
		}

		scInput.close();
	}

	private static void productManagement(Scanner scInput, IProductService productService) {
		int innerChoice = -1;

		while (innerChoice != 0) {
			System.out.println("Product Management Menu:");
			System.out.println("1. Create Product");
			System.out.println("2. Update Product");
			System.out.println("3. Delete Product");
			System.out.println("4. View Product by ID");
			System.out.println("5. View All Products");
			System.out.println("0. Exit to Main Menu");
			System.out.print("Please enter your choice: ");

			innerChoice = scInput.nextInt();
			scInput.nextLine(); 
			switch (innerChoice) {
			case 1:
				createProduct(scInput, productService);
				break;
			case 2:
				updateProduct(scInput, productService);
				break;
			case 3:
				deleteProduct(scInput, productService);
				break;
			case 4:
				getProductById(scInput, productService);
				break;
			case 5:
				getAllProducts(productService);
				break;
			case 0:
				System.out.println("Exiting to Main Menu.");
				break;
			default:
				System.out.println("Incorrect option. Please try again.");
				break;
			}
		}
	}

	private static void createProduct(Scanner scInput, IProductService productService) {
		System.out.print("Enter product name: ");
		String productName = scInput.nextLine();

		System.out.print("Enter price: ");
		double price = scInput.nextDouble();

		System.out.print("Enter quantity in stock: ");
		int quantityInStock = scInput.nextInt();
		scInput.nextLine();

		System.out.print("Enter product type: ");
		String type = scInput.nextLine();

		int result = productService.createProduct(productName, price, quantityInStock, type);

		if (result == 1) {
			System.out.println("Product created successfully.");
		} else {
			System.out.println("Failed to create product. Please try again.");
		}
	}

	private static void updateProduct(Scanner scInput, IProductService productService) {
		System.out.print("Enter product ID: ");
		int productId = scInput.nextInt();
		scInput.nextLine(); // Consume newline

		System.out.print("Enter new product name: ");
		String productName = scInput.nextLine();

		System.out.print("Enter new price: ");
		double price = scInput.nextDouble();

		System.out.print("Enter new quantity in stock: ");
		int quantityInStock = scInput.nextInt();
		scInput.nextLine(); 

		System.out.print("Enter new product type: ");
		String type = scInput.nextLine();

		int result = productService.updateProduct(productId, productName, price, quantityInStock, type);

		if (result == 1) {
			System.out.println("Product updated successfully.");
		} else {
			System.out.println("Failed to update product. Please try again.");
		}
	}

	private static void deleteProduct(Scanner scInput, IProductService productService) {
		System.out.print("Enter product ID to delete: ");
		int productId = scInput.nextInt();
		scInput.nextLine(); 

		int result = productService.deleteProduct(productId);

		if (result == 1) {
			System.out.println("Product deleted successfully.");
		} else {
			System.out.println("Failed to delete product. Please try again.");
		}
	}

	private static void getProductById(Scanner scInput, IProductService productService) {
		System.out.print("Enter product ID to view: ");
		int productId = scInput.nextInt();
		scInput.nextLine(); // Consume newline

		Product product = productService.getProductById(productId);

		if (product != null) {
			System.out.println("Product Details:");
			System.out.println(product);
		} else {
			System.out.println("Product not found.");
		}
	}

	private static void getAllProducts(IProductService productService) {
		List<Product> productList = productService.getAllProducts();

		if (productList != null && !productList.isEmpty()) {
			System.out.println("All Products:");
			for (Product product : productList) {
				System.out.println(product);
			}
		} else {
			System.out.println("No products found.");
		}
	}

	private static void orderManagement(Scanner scInput, IOrderService orderService, IProductService productService) {
		int innerChoice = -1;

		while (innerChoice != 0) {
			System.out.println("Order Management Menu:");
			System.out.println("1. Create Order");
			System.out.println("2. Update Order");
			System.out.println("3. Delete Order");
			System.out.println("4. View Order by ID");
			System.out.println("5. View All Orders");
			System.out.println("0. Exit to Main Menu");
			System.out.print("Please enter your choice: ");

			innerChoice = scInput.nextInt();
			scInput.nextLine(); 

			switch (innerChoice) {
			case 1:
				createOrder(scInput, orderService, productService);
				break;
			case 2:
				updateOrder(scInput, orderService, productService);
				break;
			case 3:
				deleteOrder(scInput, orderService);
				break;
			case 4:
				getOrderById(scInput, orderService);
				break;
			case 5:
				getAllOrders(orderService);
				break;
			case 0:
				System.out.println("Exiting to Main Menu.");
				break;
			default:
				System.out.println("Incorrect option. Please try again.");
				break;
			}
		}
	}

	private static void createOrder(Scanner scInput, IOrderService orderService, IProductService productService) {
		System.out.print("Enter order date (YYYY-MM-DD): ");
		String orderDateStr = scInput.nextLine();
		LocalDate orderDate = LocalDate.parse(orderDateStr);

		System.out.print("Enter product ID: ");
		int productId = scInput.nextInt();
		scInput.nextLine(); 
		System.out.print("Enter quantity: ");
		int quantity = scInput.nextInt();
		scInput.nextLine(); 

		int result = orderService.createOrder(orderDate, productId, quantity);

		if (result == 1) {
			System.out.println("Order created successfully.");
		} else {
			System.out.println("Failed to create order. Please try again.");
		}
	}

	private static void updateOrder(Scanner scInput, IOrderService orderService, IProductService productService) {
		System.out.print("Enter order ID: ");
		int orderId = scInput.nextInt();
		scInput.nextLine(); 

		System.out.print("Enter new order date (YYYY-MM-DD): ");
		String orderDateStr = scInput.nextLine();
		LocalDate orderDate = LocalDate.parse(orderDateStr);

		System.out.print("Enter new product ID: ");
		int productId = scInput.nextInt();
		scInput.nextLine(); 
		
		System.out.print("Enter new quantity: ");
		int quantity = scInput.nextInt();
		scInput.nextLine(); 

		int result = orderService.updateOrder(orderId, orderDate, productId, quantity);

		if (result == 1) {
			System.out.println("Order updated successfully.");
		} else {
			System.out.println("Failed to update order. Please try again.");
		}
	}

	private static void deleteOrder(Scanner scInput, IOrderService orderService) {
		System.out.print("Enter order ID to delete: ");
		int orderId = scInput.nextInt();
		scInput.nextLine(); // Consume newline

		int result = orderService.deleteOrder(orderId);

		if (result == 1) {
			System.out.println("Order deleted successfully.");
		} else {
			System.out.println("Failed to delete order. Please try again.");
		}
	}

	private static void getOrderById(Scanner scInput, IOrderService orderService) {
		System.out.print("Enter order ID to view: ");
		int orderId = scInput.nextInt();
		scInput.nextLine(); 

		Order order = orderService.getOrderById(orderId);

		if (order != null) {
			System.out.println("Order Details:");
			System.out.println(order);
		} else {
			System.out.println("Order not found.");
		}
	}

	private static void getAllOrders(IOrderService orderService) {
		List<Order> orderList = orderService.getAllOrders();

		if (orderList != null && !orderList.isEmpty()) {
			System.out.println("All Orders:");
			for (Order order : orderList) {
				System.out.println(order);
			}
		} else {
			System.out.println("No orders found.");
		}
	}

}
