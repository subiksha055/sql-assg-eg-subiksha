package com.ordermanage.dao;

import java.sql.SQLException;
import java.util.List;

import com.ordermanage.entity.Order;
import com.ordermanage.exception.OrderNotFoundException;

public interface IOrderDAO {
	int createOrder(Order order) throws ClassNotFoundException, SQLException;
    int updateOrder(Order order) throws ClassNotFoundException, SQLException, OrderNotFoundException;
    int deleteOrder(int orderId) throws ClassNotFoundException, SQLException, OrderNotFoundException;
    Order getOrderById(int orderId) throws ClassNotFoundException, SQLException, OrderNotFoundException;
    List<Order> getAllOrders() throws ClassNotFoundException, SQLException, OrderNotFoundException;

}
