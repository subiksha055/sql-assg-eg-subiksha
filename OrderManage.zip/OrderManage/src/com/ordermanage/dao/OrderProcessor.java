package com.ordermanage.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.ordermanage.entity.Product;
import com.ordermanage.entity.User;
import com.ordermanage.exception.OrderNotFoundException;
import com.ordermanage.exception.UserNotFoundException;
import com.ordermanage.service.IProductService;
import com.ordermanage.service.ProductServiceImpl;
import com.ordermanage.util.DBUtil;

public class OrderProcessor implements IOrderManagementRepository {

	@Override
	public int createOrder(User user, List<Product> products) throws UserNotFoundException, SQLException, ClassNotFoundException {
		  Connection connOrder = DBUtil.createConnection();
	        String insertOrderQuery = "INSERT INTO orders(user_id) VALUES(?)";
	        String insertOrderProductQuery = "INSERT INTO order_products(order_id, product_id) VALUES(?, ?)";

	        int orderId = 0;

	        try (PreparedStatement insertOrderStmt = connOrder.prepareStatement(insertOrderQuery, PreparedStatement.RETURN_GENERATED_KEYS);
	             PreparedStatement insertOrderProductStmt = connOrder.prepareStatement(insertOrderProductQuery)) {

	            insertOrderStmt.setInt(1, user.getUserId());
	            int affectedRows = insertOrderStmt.executeUpdate();

	            if (affectedRows == 0) {
	                throw new SQLException("Creating order failed, no rows affected.");
	            }

	            try (ResultSet generatedKeys = insertOrderStmt.getGeneratedKeys()) {
	                if (generatedKeys.next()) {
	                    orderId = generatedKeys.getInt(1);
	                } else {
	                    throw new SQLException("Creating order failed, no ID obtained.");
	                }
	            }

	            for (Product product : products) {
	                insertOrderProductStmt.setInt(1, orderId);
	                insertOrderProductStmt.setInt(2, product.getProductid());
	                insertOrderProductStmt.addBatch();
	            }

	            insertOrderProductStmt.executeBatch();

	        } finally {
	            DBUtil.closeConnection();
	        }

	        return orderId;
		
	}

	@Override
	public void cancelOrder(int userId, int orderId) throws UserNotFoundException, OrderNotFoundException, SQLException, ClassNotFoundException {
		Connection connOrder = DBUtil.createConnection();

        String checkOrderQuery = "SELECT * FROM orders WHERE order_id = ? AND user_id = ?";
        String deleteOrderQuery = "DELETE FROM orders WHERE order_id = ?";
        String deleteOrderProductsQuery = "DELETE FROM order_products WHERE order_id = ?";

        try (PreparedStatement checkOrderStmt = connOrder.prepareStatement(checkOrderQuery);
             PreparedStatement deleteOrderStmt = connOrder.prepareStatement(deleteOrderQuery);
             PreparedStatement deleteOrderProductsStmt = connOrder.prepareStatement(deleteOrderProductsQuery)) {

            checkOrderStmt.setInt(1, orderId);
            checkOrderStmt.setInt(2, userId);

            try (ResultSet rs = checkOrderStmt.executeQuery()) {
                if (!rs.next()) {
                    throw new OrderNotFoundException("Order with ID " + orderId + " not found for user with ID " + userId);
                }
            }

            deleteOrderProductsStmt.setInt(1, orderId);
            deleteOrderProductsStmt.executeUpdate();

            deleteOrderStmt.setInt(1, orderId);
            deleteOrderStmt.executeUpdate();

        } finally {
            DBUtil.closeConnection();
        }
    }
		
	

	@Override
	public void createProduct(User user, Product product) throws UserNotFoundException, SQLException, ClassNotFoundException {
		Connection connOrder = DBUtil.createConnection();

        // Check if the user is an admin and exists in the database
        if (!isAdminUser(connOrder, user.getUserId())) {
            throw new UserNotFoundException("Admin user with ID " + user.getUserId() + " not found.");
        }

        String insertProductQuery = "INSERT INTO products(product_name, price, quantity_in_stock, type) VALUES(?, ?, ?, ?)";

        try (PreparedStatement insertProductStmt = connOrder.prepareStatement(insertProductQuery)) {
            insertProductStmt.setString(1, product.getProductName());
            insertProductStmt.setDouble(2, product.getPrice());
            insertProductStmt.setInt(3, product.getQuantityInStock());
            insertProductStmt.setString(4, product.getType());

            insertProductStmt.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace(); // Handle or log the exception
        } finally {
            DBUtil.closeConnection();
        }
    }
	private boolean isAdminUser(Connection connOrder, int userId) {
		// TODO Auto-generated method stub
		return false;
	}
	

	@Override
	public void createUser(User user) throws ClassNotFoundException, SQLException {
		 Connection connOrder = DBUtil.createConnection();

	        String insertUserQuery = "INSERT INTO users(username, password, role) VALUES(?, ?, ?)";

	        try (PreparedStatement insertUserStmt = connOrder.prepareStatement(insertUserQuery)) {
	            insertUserStmt.setString(1, user.getUsername());
	            insertUserStmt.setString(2, user.getPassword());
	            insertUserStmt.setString(3, user.getRole());

	            insertUserStmt.executeUpdate();
	        } catch (SQLException e) {
	            e.printStackTrace(); // Handle or log the exception
	        } finally {
	            DBUtil.closeConnection();
	        }
	    
		
	}

	@Override
	public List<Product> getAllProducts() throws SQLException, ClassNotFoundException {
		Connection connOrder = DBUtil.createConnection();
        List<Product> productList = new ArrayList<>();

        String query = "SELECT * FROM products";

        try (PreparedStatement stmt = connOrder.prepareStatement(query)) {
            try (ResultSet rs = stmt.executeQuery()) {
                while (rs.next()) {
                    int productId = rs.getInt("product_id");
                    String productName = rs.getString("product_name");
                    double price = rs.getDouble("price");
                    int quantityInStock = rs.getInt("quantity_in_stock");
                    String type = rs.getString("type");

                    // Assuming ProductService is a service for managing products
                    IProductService productService = new ProductServiceImpl();
                    Product product = productService.getProductById(productId);
                    if (product == null) {
                        product = new Product(productId, productName, type, price, quantityInStock, type, null);
                    }

                    productList.add(product);
                }
            }
        } catch (SQLException e) {
            e.printStackTrace(); // Handle or log the exception
        } finally {
            DBUtil.closeConnection();
        }

        return productList;
	}

	@Override
	public List<Product> getOrderByUser(User user) {
		// TODO Auto-generated method stub
		return null;
	}

}
