package com.ordermanage.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.ordermanage.entity.Product;
import com.ordermanage.exception.ProductNotFoundException;
import com.ordermanage.util.DBUtil;

public class ProductDAOImpl implements IProductDAO {
	 private static Connection connProduct;

	    @Override
	    public int createProduct(Product product) throws ClassNotFoundException, SQLException {
	        connProduct = DBUtil.createConnection();
	        String query = "INSERT INTO product(product_id, product_name, description, price, quantity_in_stock, type) "
	                + "VALUES(?,?,?,?,?,?)";

	        PreparedStatement prepareStProduct = connProduct.prepareStatement(query);
	        prepareStProduct.setInt(1, product.getProductid());
	        prepareStProduct.setString(2, product.getProductName());
	        prepareStProduct.setString(3, product.getDescription());
	        prepareStProduct.setDouble(4, product.getPrice());
	        prepareStProduct.setInt(5, product.getQuantityInStock());
	        prepareStProduct.setString(6, product.getType());

	        int result = prepareStProduct.executeUpdate();

	        DBUtil.closeConnection();
	        return result;
	    }

	    @Override
	    public int updateProduct(Product product) throws ClassNotFoundException, SQLException, ProductNotFoundException {
	        connProduct = DBUtil.createConnection();
	        String query = "UPDATE product SET product_name=?, description=?, price=?, quantity_in_stock=?, type=? "
	                + "WHERE product_id=?";

	        PreparedStatement prepareStProduct = connProduct.prepareStatement(query);
	        prepareStProduct.setString(1, product.getProductName());
	        prepareStProduct.setString(2, product.getDescription());
	        prepareStProduct.setDouble(3, product.getPrice());
	        prepareStProduct.setInt(4, product.getQuantityInStock());
	        prepareStProduct.setString(5, product.getType());
	        prepareStProduct.setInt(6, product.getProductid());

	        int result = prepareStProduct.executeUpdate();

	        DBUtil.closeConnection();
	        return result;
	    }

	    @Override
	    public int deleteProduct(int productId) throws ClassNotFoundException, SQLException, ProductNotFoundException {
	        Product product = null;

	        connProduct = DBUtil.createConnection();

	        String queryCheck = "SELECT * FROM product WHERE product_id = ?";
	        String queryDelete = "DELETE FROM product WHERE product_id = ?";

	        int success = 0;

	        PreparedStatement prepareStProductCheck = connProduct.prepareStatement(queryCheck);
	        PreparedStatement prepareStProductDelete = connProduct.prepareStatement(queryDelete);

	        prepareStProductCheck.setInt(1, productId);
	        prepareStProductDelete.setInt(1, productId);

	        ResultSet rsProduct = prepareStProductCheck.executeQuery();

	        while (rsProduct.next()) {
	            product = new Product();
	            product.setProductid(rsProduct.getInt("product_id"));
	        }

	        if (product == null) {
	            throw new ProductNotFoundException("No Product Found");
	        } else {
	            success = prepareStProductDelete.executeUpdate();
	        }

	        DBUtil.closeConnection();
	        return success;
	    }

	    @Override
	    public Product getProductById(int productId) throws ClassNotFoundException, SQLException, ProductNotFoundException {
	        Product product = null;

	        connProduct = DBUtil.createConnection();

	        String query = "SELECT * FROM product WHERE product_id = ?";

	        PreparedStatement prepareStProduct = connProduct.prepareStatement(query);
	        prepareStProduct.setInt(1, productId);

	        ResultSet rsProduct = prepareStProduct.executeQuery();

	        while (rsProduct.next()) {
	            product = new Product();
	            product.setProductid(rsProduct.getInt("product_id"));
	            product.setProductName(rsProduct.getString("product_name"));
	            product.setDescription(rsProduct.getString("description"));
	            product.setPrice(rsProduct.getDouble("price"));
	            product.setQuantityInStock(rsProduct.getInt("quantity_in_stock"));
	            product.setType(rsProduct.getString("type"));
	        }

	        if (product == null) {
	            throw new ProductNotFoundException("No Product Found");
	        }

	        DBUtil.closeConnection();
	        return product;
	    }

	    @Override
	    public List<Product> getAllProducts() throws ClassNotFoundException, SQLException, ProductNotFoundException {
	        List<Product> productList = new ArrayList<>();

	        connProduct = DBUtil.createConnection();

	        String query = "SELECT * FROM product";

	        PreparedStatement prepareStProduct = connProduct.prepareStatement(query);

	        ResultSet rsProduct = prepareStProduct.executeQuery();

	        while (rsProduct.next()) {
	            Product product = new Product();
	            product.setProductid(rsProduct.getInt("product_id"));
	            product.setProductName(rsProduct.getString("product_name"));
	            product.setDescription(rsProduct.getString("description"));
	            product.setPrice(rsProduct.getDouble("price"));
	            product.setQuantityInStock(rsProduct.getInt("quantity_in_stock"));
	            product.setType(rsProduct.getString("type"));

	            productList.add(product);
	        }

	        if (productList.size() == 0) {
	            throw new ProductNotFoundException("No Products Found");
	        }

	        DBUtil.closeConnection();
	        return productList;
	    }
	

}
