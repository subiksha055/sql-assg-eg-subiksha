package com.ordermanage.dao;

import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.ordermanage.entity.Order;
import com.ordermanage.entity.Product;
import com.ordermanage.exception.OrderNotFoundException;
import com.ordermanage.util.DBUtil;

public class OrderDAOIpml implements IOrderDAO {
	 private static Connection connOrder;

	@Override
	public int createOrder(Order order) throws ClassNotFoundException, SQLException {
		connOrder = DBUtil.createConnection();
        String query = "INSERT INTO orders(order_date, product_id, quantity, total_amount) VALUES(?,?,?,?)";

        Date orderDate = Date.valueOf(order.getOrderDate());

        PreparedStatement prepareStOrder = connOrder.prepareStatement(query);
        prepareStOrder.setDate(1, orderDate);
        prepareStOrder.setInt(2, order.getProduct().getProductid());
        prepareStOrder.setInt(3, order.getQuantity());
        prepareStOrder.setDouble(4, order.getTotalAmount());

        int result = prepareStOrder.executeUpdate();

        DBUtil.closeConnection();
        return result;
    
	}

	@Override
	public int updateOrder(Order order) throws ClassNotFoundException, SQLException, OrderNotFoundException {
		connOrder = DBUtil.createConnection();
        String query = "UPDATE orders SET order_date=?, product_id=?, quantity=?, total_amount=? WHERE order_id=?";

        Date orderDate = Date.valueOf(order.getOrderDate());

        PreparedStatement prepareStOrder = connOrder.prepareStatement(query);
        prepareStOrder.setDate(1, orderDate);
        prepareStOrder.setInt(2, order.getProduct().getProductid());
        prepareStOrder.setInt(3, order.getQuantity());
        prepareStOrder.setDouble(4, order.getTotalAmount());
        prepareStOrder.setInt(5, order.getOrderId());

        int result = prepareStOrder.executeUpdate();

        DBUtil.closeConnection();
        return result;
	}

	@Override
	public int deleteOrder(int orderId) throws ClassNotFoundException, SQLException, OrderNotFoundException {
		 Order order = null;

	        connOrder = DBUtil.createConnection();

	        String queryCheck = "SELECT * FROM orders WHERE order_id = ?";
	        String queryDelete = "DELETE FROM orders WHERE order_id = ?";

	        int success = 0;

	        PreparedStatement prepareStOrderCheck = connOrder.prepareStatement(queryCheck);
	        PreparedStatement prepareStOrderDelete = connOrder.prepareStatement(queryDelete);

	        prepareStOrderCheck.setInt(1, orderId);
	        prepareStOrderDelete.setInt(1, orderId);

	        ResultSet rsOrder = prepareStOrderCheck.executeQuery();

	        while (rsOrder.next()) {
	            order = new Order();
	            order.setOrderId(rsOrder.getInt("order_id"));
	            order.setOrderDate(rsOrder.getDate("order_date").toLocalDate());

	          
	            int productId = rsOrder.getInt("product_id");
	            Product product = getProductById(productId);
	            order.setProduct(product);

	            order.setQuantity(rsOrder.getInt("quantity"));
	            order.setTotalAmount(rsOrder.getDouble("total_amount"));
	        }

	        if (order == null) {
	            throw new OrderNotFoundException("No Order Found");
	        } else {
	            success = prepareStOrderDelete.executeUpdate();
	        }

	        DBUtil.closeConnection();
	        return success;
	}

	private Product getProductById(int productId) {
		// TODO Auto-generated method stub
		return null;
	}

	public Order getOrderById(int productId) throws SQLException, ClassNotFoundException, OrderNotFoundException {
		Order order = null;

        connOrder = DBUtil.createConnection();

        String query = "SELECT * FROM orders WHERE order_id = ?";

        PreparedStatement prepareStOrder = connOrder.prepareStatement(query);
        int orderId = 0;
		prepareStOrder.setInt(1, orderId);

        ResultSet rsOrder = prepareStOrder.executeQuery();

        while (rsOrder.next()) {
            order = new Order();
            order.setOrderId(rsOrder.getInt("order_id"));
            order.setOrderDate(rsOrder.getDate("order_date").toLocalDate());

            
            int productId1 = rsOrder.getInt("product_id");
            Product product = getProductById(productId1);
            order.setProduct(product);

            order.setQuantity(rsOrder.getInt("quantity"));
            order.setTotalAmount(rsOrder.getDouble("total_amount"));
        }

        if (order == null) {
            throw new OrderNotFoundException("No Order Found");
        }

        DBUtil.closeConnection();
        return order;
	}

	
	

	@Override
	public List<Order> getAllOrders() throws ClassNotFoundException, SQLException, OrderNotFoundException {
		List<Order> orderList = new ArrayList<>();

        connOrder = DBUtil.createConnection();

        String query = "SELECT * FROM orders";

        PreparedStatement prepareStOrder = connOrder.prepareStatement(query);

        ResultSet rsOrder = prepareStOrder.executeQuery();

        while (rsOrder.next()) {
            Order order = new Order();
            order.setOrderId(rsOrder.getInt("order_id"));
            order.setOrderDate(rsOrder.getDate("order_date").toLocalDate());

           
            int productId = rsOrder.getInt("product_id");
            Product product = getProductById(productId);
            order.setProduct(product);

            order.setQuantity(rsOrder.getInt("quantity"));
            order.setTotalAmount(rsOrder.getDouble("total_amount"));

            orderList.add(order);
        }

        if (orderList.size() == 0) {
            throw new OrderNotFoundException("No Orders Found");
        }

        DBUtil.closeConnection();
        return orderList;
	}
	
}
