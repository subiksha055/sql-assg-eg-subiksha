package com.ordermanage.dao;

import java.sql.SQLException;
import java.util.List;

import com.ordermanage.entity.Product;
import com.ordermanage.entity.User;
import com.ordermanage.exception.OrderNotFoundException;
import com.ordermanage.exception.UserNotFoundException;

public interface IOrderManagementRepository {

	int createOrder(User user, List<Product> products) throws UserNotFoundException, SQLException, ClassNotFoundException;

	void cancelOrder(int userId, int orderId) throws UserNotFoundException, OrderNotFoundException, SQLException, ClassNotFoundException;

	void createProduct(User user, Product product) throws UserNotFoundException, SQLException, ClassNotFoundException;

	void createUser(User user) throws ClassNotFoundException, SQLException;

	List<Product> getAllProducts() throws SQLException, ClassNotFoundException;

	List<Product> getOrderByUser(User user);
}
