package com.ordermanage.dao;

import java.sql.SQLException;
import java.util.List;

import com.ordermanage.entity.Product;
import com.ordermanage.exception.ProductNotFoundException;

public interface IProductDAO {

	int createProduct(Product product) throws ClassNotFoundException, SQLException;

	int updateProduct(Product product) throws ClassNotFoundException, SQLException, ProductNotFoundException;

	int deleteProduct(int productId) throws ClassNotFoundException, SQLException, ProductNotFoundException;

	Product getProductById(int productId) throws ClassNotFoundException, SQLException, ProductNotFoundException;

	List<Product> getAllProducts() throws ClassNotFoundException, SQLException, ProductNotFoundException;
}
