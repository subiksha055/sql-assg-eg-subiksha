package com.ordermanage.service;

import java.sql.SQLException;
import java.time.LocalDate;
import java.util.List;

import com.ordermanage.dao.IOrderDAO;
import com.ordermanage.dao.OrderDAOIpml;
import com.ordermanage.entity.Order;
import com.ordermanage.entity.Product;
import com.ordermanage.exception.OrderNotFoundException;

public class OrderServiceImpl implements IOrderService {
	 private IOrderDAO orderDAO;

	    public OrderServiceImpl() {
	        this.orderDAO = new OrderDAOIpml();
	    }

	    @Override
	    public int createOrder(LocalDate orderDate, int productId, int quantity) {
	        int result = 0;
	        try {
	            Order order = new Order();
	            order.setOrderDate(orderDate);
	            Product product = new Product();
	            product.setProductid(productId);
	            order.setProduct(product);
	            order.setQuantity(quantity);
	            order.setTotalAmount(calculateTotalAmount(product, quantity));

	            result = orderDAO.createOrder(order);
	        } catch (ClassNotFoundException cnfe) {
	            System.out.println("Looks like JDBC driver is NOT loaded.");
	        } catch (SQLException se) {
	            System.out.println("Either url, username, or password is wrong or duplicate record");
	            se.printStackTrace();
	        }
	        return result;
	    }

	    @Override
	    public int updateOrder(int orderId, LocalDate orderDate, int productId, int quantity) {
	        int result = 0;
	        try {
	            Order order = new Order();
	            order.setOrderId(orderId);
	            order.setOrderDate(orderDate);
	            Product product = new Product();
	            product.setProductid(productId);
	            order.setProduct(product);
	            order.setQuantity(quantity);
	            order.setTotalAmount(calculateTotalAmount(product, quantity));

	            result = orderDAO.updateOrder(order);
	        } catch (ClassNotFoundException cnfe) {
	            System.out.println("Looks like JDBC driver is NOT loaded.");
	        } catch (SQLException se) {
	            System.out.println("Either url, username, or password is wrong or duplicate record");
	            se.printStackTrace();
	        } catch (OrderNotFoundException onfe) {
	            System.out.println(onfe.getMessage());
	        }
	        return result;
	    }

	    @Override
	    public int deleteOrder(int orderId) {
	        int result = 0;
	        try {
	            result = orderDAO.deleteOrder(orderId);
	        } catch (ClassNotFoundException cnfe) {
	            System.out.println("Looks like JDBC driver is NOT loaded.");
	        } catch (SQLException se) {
	            System.out.println("Either url, username, or password is wrong or duplicate record");
	            se.printStackTrace();
	        } catch (OrderNotFoundException onfe) {
	            System.out.println(onfe.getMessage());
	        }

	        return result;
	    }

	    @Override
	    public Order getOrderById(int orderId) {
	        Order order = null;

	        try {
	            order = orderDAO.getOrderById(orderId);
	        } catch (ClassNotFoundException cnfe) {
	            System.out.println("Looks like JDBC driver is NOT loaded.");
	        } catch (SQLException se) {
	            System.out.println("Either url, username, or password is wrong or duplicate record");
	        } catch (OrderNotFoundException onfe) {
	            System.out.println(onfe.getMessage());
	        }

	        return order;
	    }

	    @Override
	    public List<Order> getAllOrders() {
	        List<Order> orderList = null;

	        try {
	            orderList = orderDAO.getAllOrders();
	        } catch (ClassNotFoundException cnfe) {
	            System.out.println("Looks like JDBC driver is NOT loaded.");
	        } catch (SQLException se) {
	            System.out.println("Either url, username, or password is wrong or duplicate record");
	        } catch (OrderNotFoundException onfe) {
	            System.out.println(onfe.getMessage());
	        }
	        return orderList;
	    }

	    // Helper method to calculate total amount based on product price and quantity
	    private double calculateTotalAmount(Product product, int quantity) {
	        return product.getPrice() * quantity;
	    }

}
