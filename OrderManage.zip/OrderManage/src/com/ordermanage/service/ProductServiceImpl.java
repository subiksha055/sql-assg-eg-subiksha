package com.ordermanage.service;

import java.sql.SQLException;
import java.util.List;

import com.ordermanage.dao.IProductDAO;
import com.ordermanage.dao.ProductDAOImpl;
import com.ordermanage.entity.Product;
import com.ordermanage.exception.ProductNotFoundException;

public class ProductServiceImpl implements IProductService {

	private IProductDAO productDAO;

    public ProductServiceImpl() {
        this.productDAO = new ProductDAOImpl();
    }

    @Override
	public int createProduct(String productName, double price, int quantityInStock, String type) {

        int result = 0;
        try {
            Product product = null;
			result = productDAO.createProduct(product);
        } catch (ClassNotFoundException cnfe) {
            System.out.println("Looks like JDBC driver is NOT loaded.");
        } catch (SQLException se) {
            System.out.println("Either url, username, or password is wrong or duplicate record");
            se.printStackTrace();
        }
        return result;
    }

    @Override
    public int updateProduct(int productId, String productName, double price, int quantityInStock, String type) {
        int result = 0;
        try {
            Product product = null;
			result = productDAO.updateProduct(product);
        } catch (ClassNotFoundException cnfe) {
            System.out.println("Looks like JDBC driver is NOT loaded.");
        } catch (SQLException se) {
            System.out.println("Either url, username, or password is wrong or duplicate record");
            se.printStackTrace();
        } catch (ProductNotFoundException pnfe) {
            System.out.println(pnfe.getMessage());
        }
        return result;
    }

    @Override
    public int deleteProduct(int productId) {
        int result = 0;
        try {
            result = productDAO.deleteProduct(productId);
        } catch (ClassNotFoundException cnfe) {
            System.out.println("Looks like JDBC driver is NOT loaded.");
        } catch (SQLException se) {
            System.out.println("Either url, username, or password is wrong or duplicate record");
            se.printStackTrace();
        } catch (ProductNotFoundException pnfe) {
            System.out.println(pnfe.getMessage());
        }

        return result;
    }

    @Override
    public Product getProductById(int productId) {
        Product product = null;

        try {
            product = productDAO.getProductById(productId);
        } catch (ClassNotFoundException cnfe) {
            System.out.println("Looks like JDBC driver is NOT loaded.");
        } catch (SQLException se) {
            System.out.println("Either url, username, or password is wrong or duplicate record");
        } catch (ProductNotFoundException pnfe) {
            System.out.println(pnfe.getMessage());
        }

        return product;
    }

    @Override
    public List<Product> getAllProducts() {
        List<Product> productList = null;

        try {
            productList = productDAO.getAllProducts();
        } catch (ClassNotFoundException cnfe) {
            System.out.println("Looks like JDBC driver is NOT loaded.");
        } catch (SQLException se) {
            System.out.println("Either url, username, or password is wrong or duplicate record");
        } catch (ProductNotFoundException pnfe) {
            System.out.println(pnfe.getMessage());
        }
        return productList;
    }



 
}
