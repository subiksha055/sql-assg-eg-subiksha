package com.ordermanage.service;

import java.time.LocalDate;
import java.util.List;

import com.ordermanage.entity.Order;

public interface IOrderService {
	public int createOrder(LocalDate orderDate, int productId, int quantity);

	public int updateOrder(int orderId, LocalDate orderDate, int productId, int quantity);

	public int deleteOrder(int orderId);

	public Order getOrderById(int orderId);

	public List<Order> getAllOrders();

	

	

}
