package com.ordermanage.service;

import java.util.List;

import com.ordermanage.entity.Product;

public interface IProductService {
	int createProduct(String productName, double price, int quantityInStock, String type);

    int updateProduct(int productId, String productName, double price, int quantityInStock, String type);

    int deleteProduct(int productId);

    Product getProductById(int productId);

    List<Product> getAllProducts();

}
