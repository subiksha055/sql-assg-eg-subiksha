package com.ordermanage.entity;

import java.util.Objects;

public class Clothing extends Product {
	private String size;
	private String color;

	public Clothing() {
		super();

	}

	
	

	public Clothing(String size, String color) {
		super();
		this.size = size;
		this.color = color;
	}



	public String getSize() {
		return size;
	}

	public void setSize(String size) {
		this.size = size;
	}

	public String getColor() {
		return color;
	}

	public void setColor(String color) {
		this.color = color;
	}

	@Override
	public String toString() {
		return "Clothing [size=" + size + ", color=" + color + "]";
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = super.hashCode();
		result = prime * result + Objects.hash(color, size);
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (!super.equals(obj))
			return false;
		if (getClass() != obj.getClass())
			return false;
		Clothing other = (Clothing) obj;
		return Objects.equals(color, other.color) && Objects.equals(size, other.size);
	}
	

}
