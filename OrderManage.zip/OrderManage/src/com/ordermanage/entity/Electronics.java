package com.ordermanage.entity;

import java.util.Objects;

public class Electronics extends Product {
	private String brand;
	private int warrantyPeriod;

	public Electronics() {
		super();

	}
	

	public Electronics(String brand, int warrantyPeriod) {
		super();
		this.brand = brand;
		this.warrantyPeriod = warrantyPeriod;
	}


	@Override
	public int hashCode() {
		final int prime = 31;
		int result = super.hashCode();
		result = prime * result + Objects.hash(brand, warrantyPeriod);
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (!super.equals(obj))
			return false;
		if (getClass() != obj.getClass())
			return false;
		Electronics other = (Electronics) obj;
		return Objects.equals(brand, other.brand) && warrantyPeriod == other.warrantyPeriod;
	}

	@Override
	public String toString() {
		return "Electronics [brand=" + brand + ", warrantyPeriod=" + warrantyPeriod + "]";
	}

	public String getBrand() {
		return brand;
	}

	public void setBrand(String brand) {
		this.brand = brand;
	}

	public int getWarrantyPeriod() {
		return warrantyPeriod;
	}

	public void setWarrantyPeriod(int warrantyPeriod) {
		this.warrantyPeriod = warrantyPeriod;
	}

	

}
