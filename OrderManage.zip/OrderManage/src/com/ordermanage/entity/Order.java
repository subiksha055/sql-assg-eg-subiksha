package com.ordermanage.entity;

import java.time.LocalDate;
import java.util.Objects;

public class Order {
	 private int orderId;
	    private LocalDate orderDate;
	    private Product product;
	    private int quantity;
	    private double totalAmount;
		
	    public Order() {
			super();
			// TODO Auto-generated constructor stub
		}
		public Order(int orderId, LocalDate orderDate, Product product, int quantity, double totalAmount) {
			super();
			this.orderId = orderId;
			this.orderDate = orderDate;
			this.product = product;
			this.quantity = quantity;
			this.totalAmount = totalAmount;
		}
		public int getOrderId() {
			return orderId;
		}
		public void setOrderId(int orderId) {
			this.orderId = orderId;
		}
		public LocalDate getOrderDate() {
			return orderDate;
		}
		public void setOrderDate(LocalDate orderDate) {
			this.orderDate = orderDate;
		}
		public Product getProduct() {
			return product;
		}
		public void setProduct(Product product) {
			this.product = product;
		}
		public int getQuantity() {
			return quantity;
		}
		public void setQuantity(int quantity) {
			this.quantity = quantity;
		}
		public double getTotalAmount() {
			return totalAmount;
		}
		public void setTotalAmount(double totalAmount) {
			this.totalAmount = totalAmount;
		}
		@Override
		public String toString() {
			return "Order [orderId=" + orderId + ", orderDate=" + orderDate + ", product=" + product + ", quantity="
					+ quantity + ", totalAmount=" + totalAmount + "]";
		}
		@Override
		public int hashCode() {
			return Objects.hash(orderDate, orderId, product, quantity, totalAmount);
		}
		@Override
		public boolean equals(Object obj) {
			if (this == obj)
				return true;
			if (obj == null)
				return false;
			if (getClass() != obj.getClass())
				return false;
			Order other = (Order) obj;
			return Objects.equals(orderDate, other.orderDate) && orderId == other.orderId
					&& Objects.equals(product, other.product) && quantity == other.quantity
					&& Double.doubleToLongBits(totalAmount) == Double.doubleToLongBits(other.totalAmount);
		}

}
